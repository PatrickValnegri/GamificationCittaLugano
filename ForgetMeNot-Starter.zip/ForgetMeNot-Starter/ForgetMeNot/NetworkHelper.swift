//
//  NetworkHelper.swift
//  ForgetMeNot
//
//  Created by Ivan Pavic on 03.03.19.
//  Copyright © 2019 Ray Wenderlich. All rights reserved.
//

import Foundation
import Alamofire
import Firebase

class NetworkHelper{
    
}
